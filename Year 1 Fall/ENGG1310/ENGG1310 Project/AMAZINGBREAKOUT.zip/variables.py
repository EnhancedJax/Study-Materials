import random

# defalt ANSI settings from user
COLOR_DEFAULT = u'\u001b[0m'
# foreground colors (text)
COLOR_BLACK = u'\u001b[30m'
COLOR_RED =  u'\u001b[31m'
COLOR_GREEN = u'\u001b[32m'
COLOR_YELLOW = u'\u001b[33m'
COLOR_BLUE  =u'\u001b[34m'
COLOR_MAGENTA = u'\u001b[35m'
COLOR_CYAN = u'\u001b[36m'
COLOR_WHITE = u'\u001b[37m'
# background colors 
COLOR_BG_BLACK = u'\u001b[40m'
COLOR_BG_RED =	u'\u001b[41m'
COLOR_BG_GREEN =  u'\u001b[42m'
COLOR_BG_YELLOW = u'\u001b[43m'
COLOR_BG_BLUE = u'\u001b[44m'
COLOR_BG_MAGENTA =  u'\u001b[45m'
COLOR_BG_CYAN = u'\u001b[46m'
COLOR_BG_WHITE= u'\u001b[47m'
block_symbol = u'\u2588'

color_chars = {
}
#default chars (not unicode or ANSI coloring)
chars = {
    # default chars
    'end' : '⟋',
    'wall_v'  : block_symbol,
    'wall_h' : block_symbol,
    'wall_c' : block_symbol,
    'player' : block_symbol,
    'tail' : block_symbol,	
    'portal' : '❂',
    'empty' : ' ',
    'empty_color' : COLOR_DEFAULT,
    'wall_color' : COLOR_DEFAULT,
    'player_color' : COLOR_BLUE,
    'tail_color' : COLOR_BLACK,
    'portal_color' : COLOR_BG_MAGENTA + COLOR_WHITE,
    'end_color' : COLOR_YELLOW
}
# converted_chars = {}
# for k, v in chars.items():
#     key = k
#     if '_color' in k: continue
#     if '_' in k: key = k[0:-2]
#     converted_chars[key] = chars[f'{key}_color'] + chars[k]   + chars['empty_color']

# =====================================================================================
# =====================================================================================
# =====================================================================================

# defines hotkeys
keybinds = {
    'quit': 'x',
    'up': 'w',
    'down': 's',
    'right': 'd',
    'left': 'a',
    'confirm': '\r'
}
# convert hotkey names to ids
for k, v in keybinds.items():
    keybinds[k] = ord(v)

# =====================================================================================
# =====================================================================================
# =====================================================================================

# initiallize and fix the seed value
seed = random.random() * 10000
# home screen menu tree
menu_data_all = {
    'A mazing breakout':'title',
    'Start':{
            'Choose gamemode':'title',
            'Normal':'game_init(int(size_w / 2), int(size_h))',
            '★ Frenzy ★':'game_init(int(size_w / 2), int(size_h), frenzy=True)',
            'Squared':'game_init(min(int(size_w / 2), size_h), min(int(size_w / 2), size_h))'
        },
    'Minigame portals':{
        'Choose minigame':'title',
        '❂❂ Alchemist':'menu_initialized_minigame(1)',
        '❂❂ Typrr':'menu_initialized_minigame(2)',
        '❂❂ Quick maths!':'menu_initialized_minigame(3)'
    },
    'Quit':'menu(menu_quit)'
}
# quit screen menu
menu_quit = {
    'See you next time!':'title'
}
# break wall ability tile range
ability_range = 6
# These define the minimum window size requirements
size_w = 60
size_h = 18

# =====================================================================================
# =====================================================================================
# =====================================================================================

# helper function
def clamp(n, min_value, max_value):
        n = max(min(n, max_value), min_value)
        return n


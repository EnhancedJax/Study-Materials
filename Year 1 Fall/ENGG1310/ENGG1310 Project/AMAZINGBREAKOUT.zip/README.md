# A mazing breakout!
Game design: Everyone!
Coders: Jax, Adi
Video editors: Brian, Tommy

## Introduction
Play and complete randomized mazes! Enter portals
in the maze and complete quick minigames to earn 
the  ability  to  break  walls!  Use this to your
advantage  and  finish  as  fast  as  possible!

### Core gameplay features
Video version [here](https://youtu.be/Axye2tM2D5Q)
* Randomize generated mazes! 
* Easy controls
* Play a random minigame from a selection of 3
* Earn the ability to break walls 
* Maze sizes match terminal size!
* Frenzy mode! Instantly gain ability to break walls without completing minigames
* Timer to spice things up
### Core technical features 
Video version [here](https://youtu.be/c4HygEkD01U)
* Gets user input via unix terminal interface instead of `input()`
* Minigame class to handle all minigame-related events
* UI-like game menu, equipped with "back" function
* Player moves in direction until reaching intersection (Easy controls)
* All minigames have a unified style and print format
* Maze has a timer centered at the top edge, which can be paused
* Player movement does not require clearing the screen (no flickering)
    * We also use this technology in minigames like Typrr and QuickMaths!
* Commented code and function / objects!
* Maze has randomized portals and end points
* Welcome screen for new players, powered by our `printf()` function
    * A new screen can be easily created and used in the game

## Important
1. Do NOT resize terminal during game runtime
2. Do NOT scroll terminal during game runtime
3. Do NOT have two clients on Ed active in the same terminal 
4. If any of the above occured, please create a new terminal

## Instructions to run the game
1. Open terminal at extracted folder directory
2. Run `python main.py -new`
3. Run `python main.py` to play the game again after exiting

## Controls
Key | Game action | Menu action
 W       Up ↑                  
 A      Left ↵                 
 S      Down ↓       Down ↓    
 D      Right ↳     Confirm ↳  
Etr                 Confirm ↳  
 X      Exit ⓧ       Exit ⓧ     

 ## Acknoledgements
https://github.com/138paulmiller/PyMaze/blob/master/maze.py for maze generation function (author: Paul Miller)

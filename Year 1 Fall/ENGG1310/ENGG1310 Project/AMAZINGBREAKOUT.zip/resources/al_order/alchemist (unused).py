nicernice size_w = 110
si
#these two are the scale of the screens of this minigames

token=False

#this is a variable which detect the player had won or Lost

import random
order=random.randint(1,6) 
#this is used to pick a random order 

orderdict={1:'aa2',2:'aa3',3:'aa4',4:'aa5',5:'aa6',6:'aa7'}
realorder=orderdict[order] 

#this two lines(9 and 10) is used to find out which aa(ascii art) resource should beused

productdict={1:[1,1],2:[2,1],3:[3,2],4:[2,2],5:[1,3],6:[3,3]}
desiredproduct=productdict[order]

#this two lines(14 and 15)is used to get the correct order of the ordered product

realproduct=[] 

#this variable is used to store the input of the player

def loading(item): 
#this is a fuction where the page of aa resource would be load into a variable
    screen=[]
    #create an empty screen
    with open('/home/alchemistaa/'+item) as file:
    #finding the suitable screen
        for line in file:
            printingline=list(line)
            if printingline[-1]=='\n':
                del printingline[-1]
                screen.append(printingline)
        #putting in the suitable screen into the screen variable by list form
    return(screen)
    #return the screen in list form

#the three below fuctions are all used to print out the aa resource stored in the variable screen into visible pages
def cutscene(screen):
#this one is used for those screens which doesn't require the player to input command
    actual_h = size_h - 1    
    #this bring space for printing the roof of the screen
    print(f'╔{"═"*(size_w-2)}╗')
    #this print the roof of the screen
    for i in range(1, actual_h-3):
        center_fix = 0
        if i in range(3,3+10):
            print(''.join(screen[i-3]))
        #this print the screen stored in the variable into the terminal
        else:
            center = ''
            print(f'║{center.center(size_w-2+center_fix," ")}║')
        #this print other lines which is empty between the borders
    center='press enter to continue'
    print(f'║{center.center(size_w-2+center_fix," ")}║') 
    #this print the line which instruction is given to the player  
    print(f'╚{"═"*(size_w-2)}╝')
    #this print the bottom of the screen

def playscene(screen):
#this one is used for those screens which require the player to input command
    actual_h = size_h - 1    
    #this bring space for printing the roof of the screen
    print(f'╔{"═"*(size_w-2)}╗')
    #this print the roof of the screen
    for i in range(1, actual_h-3):
        center_fix = 0
        if i in range(3,3+10):
            print(''.join(screen[i-3]))
        #this print the screen stored in the variable into the terminal
        else:
            center = ''
            print(f'║{center.center(size_w-2+center_fix," ")}║')
        #this print other lines which is empty between the borders
    center='input the corresponding key to add the ingredient'
    print(f'║{center.center(size_w-2+center_fix," ")}║')   
    #this print the line which instruction is given to the player  
    print(f'╚{"═"*(size_w-2)}╝')
    #this print the bottom of the screen

def endingscene(screen,token):
#this one is used to print the ending scene
    actual_h = size_h - 1    
    #this bring space for printing the roof of the screen
    print(f'╔{"═"*(size_w-2)}╗')
    #this print the roof of the screen
    for i in range(1, actual_h-3):
        center_fix = 0
        if i in range(3,3+10):
            print(''.join(screen[i-3]))
        #this print the screen stored in the variable into the terminal
        elif i==actual_h-4 and token==False:
            center='token not received'
            print(f'║{center.center(size_w-2+center_fix," ")}║')
        elif i==actual_h-4 and token==True:
            center='token received'
            print(f'║{center.center(size_w-2+center_fix," ")}║')
        #these 6 lines of code(96~101) detects whether the player win or lose and print the corresponding result
        else:
            center = ''
            print(f'║{center.center(size_w-2+center_fix," ")}║')
        #this print other lines which is empty between the borders
    center='press enter to return'
    print(f'║{center.center(size_w-2+center_fix," ")}║')   
    #this print the line which instruction is given to the player 
    print(f'╚{"═"*(size_w-2)}╝')
    #this print the bottom of the screen

def alchemiststart():
    #this function capture and print the starting screen
    screen=loading('aa')
    cutscene(screen)

def alchemistfirst():
    #this fuction capture and print the screen of order which the customer gives 
    screen=loading(realorder)
    cutscene(screen)

def alchemistplay(realproduct):
    #this function is related to which the product is being actually made
    ing=0
    #this variable represent the ingredient that the player had chosen
    screen=loading('ingredient1')
    #this loads the screen of choosing the first ingredient of the product
    while ing!='1' and ing!='2' and ing!='3':
    #the while function ensure player can only proceed if valid command is input
        playscene(screen)
        #this print the ingredient choosing screen that just had been loaded
        ing=input()
        #this collects the ingredient choice from the player
    realproduct.append(int(ing))
    #this throw the ingredient chose into the product
    
    ing=0
    #this clears the variable 
    screen=loading('ingredient2')
    #this loads the screen of choosing the second ingredient of the product
    while ing!='1' and ing!='2' and ing!='3':
    #the while function ensure player can only proceed if valid command is input
        playscene(screen)
        #this print the ingredient choosing screen that just had been loaded
        ing=input()
        #this collects the ingredient choice from the player
    realproduct.append(int(ing))
    #this throw the ingredient chose into the product
    return(realproduct)
    #this return the drink list whichrecorded the two ingredients chosen by the player

def alchemistend(realproduct,desiredproduct):
    if realproduct!=desiredproduct:
        token=False
        screen=loading('aa8')
    else:
        token=True
        screen=loading('aa1')  
        #this function detect if the player's input is correct or not and record the corresponding scenary    
    endingscene(screen,token)
    #this function print the recorded screen

def alchemist():
    alchemiststart()
    void=input()
    alchemistfirst()
    void=input()
    realproduct=alchemistplay(realproduct)
    alchemistend(realproduct,desiredproduct)
alchemist()

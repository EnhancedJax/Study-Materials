import os, sys, time, maze, player, minigame, printf
from variables import *
from getchar import *

'''
menu(menu_data, selected=1, reset_history=False)
    Displays an interactable menu interface for players for players to choose their actions

globals         size_w, size_h, menu_history
menu_data       structured dictionary item with contents of each page (title and options) as well as their sub-pages inside
selected        currently selected option on the page
reset_history   if the program should forget all previously shown menus

    // author: Jax
'''
def menu(menu_data, selected=1, reset_history=False):
    global size_w, size_h, menu_history
    # reset menu history and reset seed, as resetting history indicates that the maze is either closed or completed
    if reset_history: 
        menu_history = []
        global seed
        seed = random.random() * 10000

    # appends the current menu data to the history list, without making duplicates
    if len(menu_history) > 0:
        if menu_history[-1] != menu_data:
            menu_history.append(menu_data)
    else:
        menu_history.append(menu_data)

    # must delcare title as first item in dict
    title = list(menu_data.keys())[0]

    option_count = len(menu_data) - 1
    # if there are no options in the menu (finish screen) then center title
    if option_count == 0:
        title_pos = int(size_h*0.5 - 1)
    else:
        title_pos = int(size_h*0.35)
    
    os.system('clear')

    # prints top edge
    print(f'╔{"═"*(size_w-2)}╗')
    # prints centered content one by one
    for i in range(1, size_h-2):
        # center fix for anscii tags
        center_fix = 0
        # title print style
        if i == title_pos:
            center = '== ' + title.upper() + ' =='
            center_fix = 0
        # option print style
        elif option_count > 0 and title_pos + 1 < i < title_pos + 2 + option_count:
            data_index = i - title_pos - 1
            center = list(menu_data.keys())[data_index]
            if data_index == selected:
                center = '▶ ' + center
        # controls guide style
        elif option_count > 0 and i == size_h - 4:
            center = 'Controls: WASDX (↑ ↵ ↓ ↳ ⓧ)'
            center_fix = 0
        else:
            center = ''
        # print line
        print(f'║{center.center(size_w-2+center_fix," ")}║')
    #prints bottom edge
    print(f'╚{"═"*(size_w-2)}╝')

    # don't have to detect input if not options
    if option_count == 0:
        return
    
    # detects input for menu options
    r = ord(getchar())
    if r == keybinds['up']:
        # move up one option (selected - 1) (clamped to prevent overflow)
        menu(menu_data, clamp(selected-1, 1, option_count))

    elif r == keybinds['down']:
        # move down one option (selected + 1)
        menu(menu_data, clamp(selected+1, 1, option_count))

    elif r == keybinds['right'] or r == keybinds['confirm']:
        # if the option's action is a menu, open it, else run the option action as a literal
        option_action = list(menu_data.values())[selected]
        if isinstance(option_action, dict):
            menu(option_action)
        else:
            exec(option_action)

    elif r == keybinds['left'] and len(menu_history) > 1:
        # remove current menu from menu history and go to the previous menu
        menu_history.remove(menu_history[-1])
        menu(menu_history[-1])
    elif r == keybinds['quit']:
        # display quit screen and quit
        menu(menu_quit)
    else:
        # if any other input is detected remain in current menu
        menu(menu_data)



'''
game_init(w, h, mode)
    Runs the maze game, the game is finished when the function ends

    // author: Jax
'''
def game_init(w, h, frenzy=False):
    # initiallize game object
    if frenzy:
        game = maze.Maze(w, h, seed, chars, portal_rate=0.6)
    else:
        game = maze.Maze(w, h, seed, chars)
    game.start_timer()
    game.print_game()
    # printed game serves as the base layer for the visuals, and characters will be printed over the base layer
    
    has_ability = -1
    while not game.is_done:
        if has_ability != 0: 
            r = ord(getchar())
        else:
            r = None
        
        if r == keybinds['quit']: # quits game and ends timer if the quit key is detected
            # write ending screen title
            message = 'Left game'
            is_left = True
            
            game.is_done = True
            game.end_timer()
            break
        
        for k, v in keybinds.items(): # get the name from the entered key
            if r == v: move = k
        
        if move not in ['up', 'down', 'left', 'right']: # ignore if the entered key is not a movement key
            continue
        
        if has_ability == 1: # break walls if player has ability
            game = player.break_walls(move, game, ability_range)
        if has_ability != -1: # reset ability status if minigame was played
            has_ability = -1
            os.system('clear')
            game.print_game()
            game.start_timer()
            continue


        is_first_move = True
        while True: # we move the character until it reaches an intersection
            player_moving_over = player.moving_over(game) # get a dict of the adjacent tiles direction:tile
            # detect if we've reached an intersection yet by checking if there are 3 possible directions to move from the tile
            # we shouldn't check for the first move because the player stops at an intersection
            if sum(1 for v in player_moving_over.values() if v in ['empty', 'end', 'tail']) >= 3 and not is_first_move:
                break
            is_first_move = False
            
            if player_moving_over[move] in ['empty', 'tail']: # move the player if it's possible
                game = player.move(move, game)
            
            elif player_moving_over[move] == 'end': # ends game if player reached the ending tile
                game = player.move(move, game)
                game.is_done = True # declares the game is finished to break from the outer loop
                time_elapsed = game.end_timer()
                message = f'Level completed in {time_elapsed}s!'
                is_left = False
                break
            
            elif player_moving_over[move] == 'portal': # starts minigame on entering portal
                game = player.move(move, game)

                game.pause_timer()
                time.sleep(0.05) # shows the player entering portal before clearing screen
                os.system('clear')
                if frenzy: # auto-complete minigaem if frenzy
                    mg = minigame.Minigame(size_w , size_h, 0)
                else:
                    mg = minigame.Minigame(size_w , size_h)
                game.print_game() # after minigame finish, show maze again
                if mg.is_won:
                    game.print_announcement(f'Move to break {ability_range} walls!')
                    has_ability = 1 # grants ability to player
                else:
                    game.print_announcement('Lost minigame. Ability not granted.')
                    time.sleep(1) # makes sure player have time to see announcement
                    has_ability = 0 # trigger condition for next loop 
                game.is_done = False
                continue
            else:
                # stop the player if they are running into a wall
                break

    game.is_done = False
    if not is_left: # prints finish splash screen if reached end
        printf.from_file('maze_finish', size_w, size_h)
        time.sleep(1)
    menu_end={
        message:'title',
        'Back to main screen':'menu(menu_data_all, reset_history=True)',
        'Quit':'menu(menu_quit, reset_history=True)'
    }
    menu(menu_end, reset_history=True)

def menu_initialized_minigame(idd): # function to start minigame via menu
    os.system('clear')
    mg = minigame.Minigame(size_w , size_h, idd)
    menu(menu_data_all, reset_history=True)


# =====================================================================================
# =====================================================================================
# =====================================================================================

menu_history = []
terminal_w, terminal_h = os.get_terminal_size()

if terminal_w < size_w or terminal_h < size_h: # check minimum window size requirements
    print(f'Please make sure the terminal size >= {size_w} x {size_h} chars (Currently {terminal_w} x {terminal_h}).')
else:
    size_w , size_h = terminal_w - 2, terminal_h - 2 # set game display area by terminal dimensions. Ensure no display issues
    arguments = sys.argv # get a list of arguments
    for arg in arguments:
        if arg == '-new': # if player wants to start game as new player
            for i in range(1, 5):
                printf.from_file(f'intro_{i}', size_w, size_h) # print formatted welcome screen
                while True: # checks if player clicked enter, else wait for click again
                    r = getchar()
                    if r == '\r':
                        break
    
    menu(menu_data_all) # call starting game menu

import os

'''
printf(struc, w, h)
    Prints a dictionary in a standard formatted style for the game
    @params
        struc   Dictionary line#:text and size:#, where size is the total number of lines
    @return
        a list of tuples of the (x,y) character positions of the first character in every specified line printed

    // author: Jax
'''
def printf(struc, w, h):
    size = struc['size']
    line_start = int((h - 2) / 2 + 1) - int(size / 2) # centers height:size in height:h using the formula h1/2 - h2/2
    pos_first_char = []
    print_w = w - 2 # exclude left and right edge

    print(f'╔{"═"*(print_w)}╗')
    # prints centered content one by one
    for i in range(1, h-2):
        centered = ''.center(print_w," ")
        if line_start + size - 1 >= i >= line_start: # range of line numbers where lines are printed
            text = struc[f'line{i - line_start + 1}'] # (i - line_start + 1) translates to defined line number
            centered = text.center(print_w, " ") # 
            # get position of first char of string, if string is empty then get position is in the middle
            printed_first_char = centered.index(text[0]) if text != '' else int(print_w / 2)
            pos_first_char.append((printed_first_char + 2, i + 1)) # y position is the current line number + 1 (first line not in loop)
        # print line
        print(f'║{centered}║')
    #prints bottom edge
    print(f'╚{"═"*(print_w)}╝')

    return pos_first_char

'''
from_file(filename, w, h)
    Reads lines from file and generates struc into printf 
    @params
        filename   file name.

    // author: Jax
'''
def from_file(filename, w, h):
    lines = open(f'resources/{filename}.txt', 'r').readlines()

    message_struc = {'size':0}
    for line in lines:
        message_struc['size'] += 1
        line_i = message_struc['size']
        message_struc[f'line{line_i}'] = line.replace('\n', '')
    os.system('clear')
    printf(message_struc, w, h)


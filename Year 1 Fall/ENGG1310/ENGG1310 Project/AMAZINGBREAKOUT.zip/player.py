import sys, time

def print_tile_at(x, y, char, flush=False):
    # adjusts x, y position for printing from provided grid coordinates
    x = x * 2 + 1
    y = y + 2
    # writes at said position with character and clears cache for performance
    sys.stdout.write('\033[%d;%dH%s' % (y, x, char * 2))
    if flush: sys.stdout.flush()

def moving_over(game):
    y, x = game.player_pos[0], game.player_pos[1]
    lookUp = {'up':[-1, 0], 'left':[0, -1], 'down':[1, 0], 'right':[0, 1]}

    # returns over dict direction:tile by iterating through the character list and possible movement directions
    over = {}
    for k, v in game.chars.items():
        for d in lookUp:
            # print(v, game.grid[y+lookUp[d][0]][x+lookUp[d][1]])
            if v == game.grid[y+lookUp[d][0]][x+lookUp[d][1]]:
                over[d] = k.replace('_color', '')
    return over

def move(move, game):
    lookUp = {'up':[-1, 0], 'left':[0, -1], 'down':[1, 0], 'right':[0, 1]}
    # gets current coordinates and calculates new coordinates based on var:move
    y, x = game.player_pos[0], game.player_pos[1]
    new_y, new_x = y+lookUp[move][0], x+lookUp[move][1]
    # movingOver = game[new_y][new_x]

    # modifies game.grid to new state as player moved
    game.grid[new_y][new_x] = game.player
    game.grid[y][x] = game.tail
    # update player position in game object
    game.player_pos = (new_y, new_x)
    # update visuals to player
    print_tile_at(new_x, new_y, game.player)
    print_tile_at(x, y, game.tail, flush=True)
    time.sleep(0.01)
    
    # returns and update game object
    return game

def break_walls(direction, game, n):
    y, x = game.player_pos[0], game.player_pos[1]
    lookUp = {'up':[-1, 0], 'left':[0, -1], 'down':[1, 0], 'right':[0, 1]}
    effect = {'up':'-', 'left':'|', 'down':'-', 'right':'|'}
    for i in range(1, n): # checks every tile effected
        ix = x + i * lookUp[direction][1] # tile x
        iy = y + i * lookUp[direction][0] # tile y
        if 0 < ix < game.w_bychar - 1 and 0 < iy < game.h_bychar - 1: # makes sure the proposed tile positions do not exceed bounds
            target = game.grid[iy][ix] # propose target
            if target not in game.end: # makes sure palyer does not break the exit
                print_tile_at(ix, iy, effect[direction], flush=True) # prints effect tile
                game.grid[iy][ix] = game.empty # clears tile from game, updated after function finished
                time.sleep(0.05) # effect frame delay
    # returns and update game object
    return game

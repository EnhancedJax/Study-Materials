'''
Random Maze Generator + Disjoint Set Class
Makes use of a radomized version of Kruskal's Minimum Spanning Tree (MST) 
algorithm to generate a randomized mazes!
	// author: Paul Miller (github.com/138paulmiller)

=== ACKNOWLEDGEMENT ===
Script is modified to suit the project's needs. Please note the following points:
* The sole purpose of using the code is to generate randomized levels for the game
* modified and simplified class's builder (init) for the game
* modified to_str -> to_2d in order to return a nested list for the game's map
	* script initially had a set end point. Added function so that it's randomized
	* random portal generation
* slightly modified init_chars and timer functions for the game
* wrote pause_timer() (kills timer and stores elapsed time into a variable)
* wrote print_game() and print_announcement()
* class ds is unmodified

Compare diff with this file: https://github.com/138paulmiller/PyMaze/blob/master/maze.py
'''
import os, sys, random, time, datetime, threading

class Maze:

	def __init__(self, width, height, seed, chars=None, portal_rate=0.4):
		width = int((width)/2)
		height = int(height/2 - 1) # - 1 because a line of the height is reserved to show timer and announcement
		# basic attributes
		self.init_chars(chars)
		self.width = width
		self.height = height
		self.seed = seed
		self.portal_rate = portal_rate
		# self.is_writing to prevent timer printing over maze
		self.is_writing = False
		# game attributes
		self.time_taken = False
		self.pause_time = 0
		self.is_done = False
		self.player_pos = (1, 1)
		# generation attributes
		self.grid = [[(width*row + col) \
			for row in range(0,height)]\
				for col in range(0, width)]
		self.transfers = {}
		# generate the maze by using a kruskals algorithm 
		self.kruskalize()
		self.grid = self.to_2d()


	def to_2d(self): # turns the maze object to a 2d array (table)
		'''START // author: Paul Miller'''
		maze=[]
		l=[]
		for col in range(0, self.width):
			l.extend([self.wall_c, self.wall_h])
		
		l.append(self.wall_c)
		maze.append(l)
		l = []
		# wall if region not the same	
		for row in range(0,self.height):
			# draw S for start if at (0,0)
			if row == 0:
				l.extend([self.wall_v, self.player])	
			else:
				l.extend([self.wall_v, self.empty])	
			# draw | if no transfer between [row][col] and [row][col-1]	
			for col in range(1, self.width): 	
				# if  theres a transfer between cell and left cell
				if self.grid[col-1][row] in self.transfers[self.grid[col][row]]:
					# if transfer remove wall
					c = [self.empty]
				else:
					# if not transfer draw vertical wall
					c = [self.wall_v]
				c.append(self.empty)				
				l.extend(c)
			l.append(self.wall_v)
			maze.append(l)
			l=[]
			# draw - if not transfer between [row][col] and [row+1][col]
			for col in range(0, self.width):
				# if edge above (visually below)
				c = self.wall_h
				key = self.grid[col][row]	
				# if not at last row, and theres a transfer between cell and above cell
				if row+1 < self.height and self.grid[col][row+1] in self.transfers[key]:
						c = self.empty
				l.extend([self.wall_c, c])
			l.append(self.wall_c)
			maze.append(l)
			l=[]
		'''END // author: Paul Miller'''
		'''START // author: Jax'''
		
		# assign random end points
		random.seed(self.seed)
		while True:
			exit_width = random.randint(int(self.width/2), self.width -1) # get a random x position at the bottom right edge
			exit_height = random.randint(1, self.height - 1) # gets a random y position at the right edge
			if random.randint(1, 2) == 1: # flip a coin to decide if the exit should be at the bottom or right edge
				if maze[exit_height][-2] == self.empty: # checks if the position is a valid exit position
					maze[exit_height][-1] = self.end
					break
				elif maze[-2][exit_width] == self.empty:
					maze[-1][exit_width] = self.end
					break
		
		# define actual h, w by character length
		self.h_bychar = len(maze)
		self.w_bychar = len(maze[0])

		# spawn random minigame portals
		spawn_padding = 5 # distance from edge where portals shouldn't spawn
		portal_candidates = []
		for r in range(spawn_padding, self.h_bychar - spawn_padding):
			for c in range(spawn_padding, self.w_bychar - spawn_padding):
				checking = maze[r][c]
				if checking is self.empty:
					# checks all 4 sides of the "checking" tile and see if it's a dead end (if 3 of it's sides are walls)
					if sum(1 for v in [maze[r][c+1], maze[r][c-1], maze[r+1][c], maze[r-1][c]] if v in [self.wall_h, self.wall_v]) >= 3:
						portal_candidates.append((r, c))
		
		# from the candidates get a sample as the winner positions for portals randomly (set rate)
		portals = random.sample(portal_candidates, int(len(portal_candidates) * self.portal_rate))
		for pos in portals: # change tiles to portals
			maze[pos[0]][pos[1]] = self.portal

		return maze

	def print_game(self): # print game map
		self.is_writing = True # stops timer printing
		os.system('clear')
		sys.stdout.write('-'*(self.w_bychar * 2) + '\n') # every character is doubled to make each tile a square in the terminal
		for row in self.grid:
			for x in row:
				sys.stdout.write(x*2)
			sys.stdout.write('\n')
		sys.stdout.flush() 
		self.is_writing = False # allows timer printing
	
	def print_announcement(self, message): # prints something at top center
		sys.stdout.write('\033[%d;%dH[%s]' % (0, self.w_bychar - len(message) / 2 - 1, message)) # % (y, x, s)
		sys.stdout.flush()
		return

	def start_timer(self):
		self.is_done = False
		self.timer_thread = threading.Thread(target=self.timer_job)
		self.timer_thread.start() 
	
	def pause_timer(self):
		self.is_done = True
		self.kill_timer()
		self.pause_time = self.time_taken

	def kill_timer(self):
		if self.timer_thread != None:
			self.timer_thread.join()

	def end_timer(self):
		self.kill_timer()
		return str(round(self.time_taken, 2))

	def timer_job(self):
		start_time = time.time() - self.pause_time
		# prints the current time at the bottom of the maze 
		while not self.is_done:
			# if not currently writing move, print time at bottom
			if not self.is_writing: 
				time_elapsed = time.time() - start_time
				# delay on the update rate (only update every 10th of a second)
				if time_elapsed - self.time_taken > 0.01: 
					self.time_taken = time_elapsed 
					# use write and flush to ensure buffer is emptied completely to avoid flicker
					sys.stdout.write('\033[%d;%dH[%.2fs]' % (0, self.width * 2, self.time_taken))
					sys.stdout.flush()
			
		self.time_taken = time.time() - start_time

	def init_chars(self, chars):
		# sets character variables by combining colors and characters
		self.player = chars['player_color'] + chars['player']   + chars['empty_color']
		self.end 	= chars['end_color'] 	+ chars['end']    	+ chars['empty_color']
		self.wall_h = chars['wall_color'] 	+ chars['wall_h'] 	+ chars['empty_color']
		self.wall_v = chars['wall_color'] 	+ chars['wall_v'] 	+ chars['empty_color']
		self.wall_c = chars['wall_color'] 	+ chars['wall_c'] 	+ chars['empty_color']
		self.tail 	= chars['tail_color'] 	+ chars['tail']   	+ chars['empty_color']
		self.portal = chars['portal_color'] + chars['portal']   	+ chars['empty_color']
		self.empty 	= chars['empty_color']	+ ' '

		# gets a dictionary of characters without the colors (for player movement in player.py)
		self.chars 	= chars.copy()
		topop = []
		for x in self.chars: 
			if hasattr(self, x):
				self.chars[x] = getattr(self, x)
			else:
				topop.append(x)
		for k in topop:
			self.chars.pop(k)
		

	'''END // author: Jax'''

	# ==================================================================================
	# ==================================================================================
	# ==================================================================================
	
	def kruskalize(self):
		'''
		Kruskal's algorithm, except when grabbing the next available edge, 
		order is randomized. 
		Uses a disjoint set to create a set of keys. 
		Then for each edge seen, the key for each cell is used to determine 
		whether or not the the keys are in the same set.
		If they are not, then the two sets each key belongs to are unioned.
		Each set represents a region on the maze, this finishes until all
		keys are reachable (MST definition) or rather all keys are unioned into 
		single set. 
		'''
		# edge = ((row1, col1), (row2, col2)) such that grid[row][col] = key
		edges_ordered = [ ]
		# First add all neighboring edges into a list
		for row in range(0, self.height):
			for col in range(0, self.width):	
				cell = (col, row)
				left_cell = (col-1, row)
				down_cell = (col, row-1)
				near = []
				# if not a boundary cell, add edge, else ignore
				if col > 0:
					near.append((left_cell, cell))
				if row > 0:
					near.append( (down_cell, cell))
				edges_ordered.extend(near)
				
		# seed the random value
		random.seed(self.seed)
		edges = []
		# shuffle the ordered edges randomly into a new list 
		while len(edges_ordered) > 0:
			# randomly pop an edge
			edges.append(edges_ordered.pop(random.randint(0,len(edges_ordered))-1))
		disjoint_set = DisjointSet()
		for row in range(0, self.height):
			for col  in range(0,self.width):
				# the key is the cells unique id
				key = self.grid[col][row]
				# create the singleton 
				disjoint_set.make_set(key)
				# intialize the keys transfer dict
				self.transfers[key] = {}
		edge_count = 0
		# eulers formula e = v-1, so the
		# minimum required edges is v for a connected graph!
		# each cell is identified by its key, and each key is a vertex on the MST
		key_count = self.grid[self.width-1][self.height-1] # last key	
		while edge_count < key_count:
			# get next edge ((row1, col1), (row2,col2))
			edge = edges.pop()
			# get the sets for each vertex in the edge
			key_a = self.grid[edge[0][0]][edge[0][1]]
			key_b = self.grid[edge[1][0]][edge[1][1]]
			set_a = disjoint_set.find(key_a)
			set_b = disjoint_set.find(key_b)
			# if they are not in the same set they are not in the 
			# same region in the maze
			if set_a != set_b:
				# add the transfer between the cells, 
				# graph is undirected and will search
				# [a][b] or [b][a]
				edge_count+=1	
				self.transfers[key_a][key_b] = True 
				self.transfers[key_b][key_a] = True 
				disjoint_set.union(set_a, set_b)

# ==================================================================================
# ==================================================================================
# ==================================================================================


class DisjointSet:
	'''
	Disjoint Set : Utility class that helps implement Kruskal MST algorithm
		Allows to check whether to keys belong to the same set and to union
		sets together
	'''
	class Element:
		def __init__(self, key):
			self.key = key
			self.parent = self
			self.rank = 0
		
		def __eq__(self, other):
			return self.key ==  other.key
		def __ne__(self, other):
			return self.key != other.key
 
	def __init__(self):
		'''
		Tree = element map where each node is a (key, parent, rank) 
		Sets are represented as subtrees whose root is identified with
		a self referential parent
		'''
		self.tree = {}
	
	def make_set(self, key):
		'''
		Creates a new singleton set.
		@params 
			key : id of the element
		@return
			None
		'''
		# Create and add a new element to the tree
		e = self.Element(key)
		if not key in self.tree.keys():
			self.tree[key] = e

			
	def find(self, key):
		'''
		Finds a given element in the tree by the key.
		@params 
			key(hashable) : id of the element
		@return
			Element : root of the set which contains element with the key
		'''
		if key in self.tree.keys():
			element = self.tree[key]
			# root is element with itself as parent
			# if not root continue
			if element.parent != element:
				element.parent  = self.find(element.parent.key)
			return element.parent

	
	def union(self, element_a, element_b):
		'''
		Creates a new set that contains all elements in both element_a and element_b's sets
		Pass into union the Elements returned by the find operation
		@params 
			element_a(Element) : Element or key of set a
			element_b(Element) : Element of set b
		@return
			None
		''' 
		root_a = self.find(element_a.key)
		root_b = self.find(element_b.key)
		# if not in the same subtree (set)
		if root_a != root_b:
			#merge the sets
			if root_a.rank < root_b.rank:
				root_a.parent = root_b
			elif root_a.rank > root_b.rank:
				root_b.parent = root_a
			else:
				# same rank, set and increment arbitrary root as parent
				root_b.parent = root_a
				root_a.rank+=1

import time, sys, os, printf
from random import randint, sample
from getchar import *

'''
print_at(x, y, s)
    prints string "s" at character position (x, y) in the terminal via ANSCII code

move_cursor_to(x, y)
    moves caret (cursor) to position (x, y) in the terminal

    // author: Jax
'''
def print_at(x, y, s):
    sys.stdout.write('\033[%d;%dH%s' % (y, x, s))
    sys.stdout.flush()

def move_cursor_to(x, y):
    sys.stdout.write('\033[%d;%dH' % (y, x))
    sys.stdout.flush()

'''
class Minigame
    Minigame object containing all minigames and useful functions
    @funcs
        __init__            Sets attributes and call start_minigame
        @params
            game            Specify minigame to play
        print_completed     Prints minigame finish screen from files nice.txt or oops.txt (if the player won or lost),
        @params
            prefix          Prefix for the files in case a different finish screen is desired to be displayed
        start_minigame      Starts minigame
        m# [#n]             Respective minigame functions

    // author: Jax, Adi
'''
class Minigame:
    def __init__(self, width, height, game=-1):
        self.size_w = width
        self.size_h = height
        self.is_won = False
        if game == -1: # start a random game if not specified
            game = randint(1, 3)
        self.start_minigame(game)
    
    def print_completed(self, result, prefix=''):
        funny = 'nice' if result else 'oops' # nice if won, oops if lost
        printf.from_file(prefix + funny, self.size_w, self.size_h)
        
        self.is_won = result
        time.sleep(1)
    
    def start_minigame(self, num):
        if num != 0:
            printf.from_file(f'{num}_splash', self.size_w, self.size_h) # prints game splash screen
            while True: # loop until user clicked enter
                r = getchar()
                if r == ' ':
                    break
            os.system('clear')
        exec(f'self.m{num}()') # runs minigame function
    
    # frenzy mode: portals as powerups
    def m0(self):
        self.is_won = True

    # alchemist Minigame
    def m1(self):
        ordernum = randint(1, 6)
        solution = {1:["3",'3'],2:['1','1'],3:['2','1'],4:['3','2'],5:['2','2'],6:['1','3']}
        product = []
        printf.from_file(f'al_order/aa{ordernum}', self.size_w, self.size_h)
        getchar()
        for i in range(1,3): # shows the ingredients options and get user input
            print(i)
            printf.from_file(f'al_order/al_ingr_{i}', self.size_w, self.size_h)
            while True: # loops until options are the keys clicked
                r = getchar()
                if r in ['1', '2', '3']:
                    product.append(r)
                    break
        self.print_completed(product == solution[ordernum], prefix="al_") # shows end screen
    
    # typing minigame
    def m2(self):
        strings = [
            'hello world \o/',
            'I sure do love ENGG1330',
            'The pws for the quizzes are SO relatable',
            'this game is SOOOOO fun omfg',
            'get me out of here get me out of here'
        ]
        message = str(sample(strings, 1)[0]) # get a random string
        message_struc = {
            'size':6,
            'line1':'== Type the following with no mistake ==',
            'line2':'',
            'line3': message,
            'line4':"_" * len(message),
            'line5':'',
            'line6':'',
            'line7':'Press Enter when finished'
        } # game screen
        p = printf.printf(message_struc, self.size_w, self.size_h)
        move_cursor_to(p[3][0], p[3][1]) # moves cursor to the screen "input field"
        r = input() # get user input
        self.print_completed(r == message) # shows end screen
    
    # math minigame
    def m3(self):
        def pos_neg(num): # if number is positive return positive sign
            if num >= 0:
                return '+'
            else:
                return ''
        questions = [
            (randint(0,4), randint(0,5)),
            (randint(0,9), randint(-9,0)),
            (randint(-9,0), randint(0,7)),
            (randint(0,9), randint(-9,0))
        ] # randomized questions
        message_struc = {
            'size':3,
            'line1':'== Quick maths! ==',
            'line2':'',
            'line3':'[__READY__]'
        } # game ready screen
        p = printf.printf(message_struc, self.size_w, self.size_h)
        time.sleep(0.5)

        answers = ''
        for q in questions: # shows a game screen for each question
            message_struc_2 = {
                'size':3,
                'line1':'== Quick maths! ==',
                'line2':'',
                'line3':f'{q[0]}{pos_neg(q[1])}{q[1]}'
            } # question screen
            os.system('clear') # clears last question
            p = printf.printf(message_struc_2, self.size_w, self.size_h) # shows screen
            answers += str(q[0] + q[1]) # adds the correct answer to the answer string
            time.sleep(1.5) # 1.5 seconds for each question
        
        print_at(p[2][0] - 6, p[2][1] + 1, 'Answer: ')
        r = input() # get user answer
        self.print_completed(r == answers) # shows end screen
    

import termios, tty, sys
'''
getchar(): Gets character input from terminal

=== ACKNOWLEDGEMENT ===
Obtained via online source at https://github.com/138paulmiller/PyMaze/blob/master/pymaze.py#L32
    // author: Paul Miller (github.com/138paulmiller)
'''
def getchar():
    # import unix terminal interface
    # get stdin file descriptor 
    file_desc = sys.stdin.fileno()
    # get stdin file settings
    settings = termios.tcgetattr(file_desc)
    try:
        # modifies settings
        tty.setraw(file_desc)
        # read a single byte 
        char = sys.stdin.read(1)
    finally:
        # set the stdin settings back to before raw modification
        termios.tcsetattr(file_desc, termios.TCSADRAIN, settings)
    return char
